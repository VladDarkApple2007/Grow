import React from 'react'
import Footer from './Component/footer/Footer.jsx';
import './Style.css'
import Navbar from './Component/navbar/Navbar.jsx';
import Home from './Pages/Home/Home.jsx';
import Shop from './Pages/Shop/Shop.jsx';
import ShopingCart from './Pages/ShopingCart/ShopCart.jsx'
import {BrowserRouter as Router, Routes, Route, Link, json, BrowserRouter} from 'react-router-dom'




function App() {
  return (
    <>

<BrowserRouter>
<Navbar/>
<Routes>
<Route path='/' element={<Home/>}/>
<Route path='/shop' element={ <Shop/>}/>
<Route path='/shop_cart' element={<ShopingCart/>}/>
</Routes>
</BrowserRouter>
  
    </>
  );
}

export default App;
