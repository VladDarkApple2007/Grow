import React, { useState } from 'react'
import './../FilterBlock/filter_block.css'

const NameFilter = ['House Plants', 'Potter Plants', 'Seeds', 'Small Plants','Big Plants','Succulents','Trerrariums','Gardening','Accessories']

const CountProduct = ['(33)', '(12)','(65)', '(39)', '(23)', '(17)', '(19)', '(13)', '(18)', ]

const SizeFilter = ['Small','Medium','Large',]

const CountSize = ['(119)', '(82)','(65)' ]

export default function FilterBlock() {

   const [activeFilter, SetActiveFilter] = useState([]);




  return (
    <div className="home_filter">
      <p className="title_filter_category">Categories</p>
      <div className="count_name_filter">
         <div className="name_filter_block">
         {NameFilter.map((name, id) => {
            return (
               <div 
                key={id}
                onClick={() => SetActiveFilter(id)}
                className={activeFilter === id ? 'active_filter' : 'name_filter'}
                >
                  {name}
               </div>
            )
         })}
         </div>
         <div className="count_filter_block">
         {CountProduct.map((count, id) => {
            return (
               <div key={id}
               className={activeFilter === id ? 'active_filter' : 'name_filter'}
               >
                  {count}
               </div>
            )
         })}
         </div>
         
      </div>
      <p className='title_filter_size'>Size</p>
      <div className="count_size_filter">
         <div className="size_filter_block">
         {SizeFilter.map((size, id) => {
            return (
               <div 
                key={id}
                >
               {size}
               </div>
            )
         })}
         </div>
         <div className="count_size_block">
         {CountSize.map((count, id) => {
            return (
               <div className='number_filter_size' key={id}
               >
                  {count}
               </div>
            )
         })}
         </div>
         
      </div>
    </div>
  )
}

// className='count_filter'