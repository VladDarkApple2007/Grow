import React from 'react'
import './../ProductHome/product_home.css'

export default function ProductHome({name, price, img, lastprice, index}) {

  return (
   <div className="product_home_flex">
<div className="product_home">
   <div className="photo_prod">
   <img src={img} alt="" />
   </div>
   <div className="photo_prod">
   <h5>{lastprice}</h5>
   </div>
      <p className='name_product_home'>{name}</p>
      <p className='price_product_home'>{price}</p>

   </div>
   </div>
  )
}
