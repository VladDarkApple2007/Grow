import MainBaner from './../../img_home/Main Banner.png'
import './../header/header.css'

export default function Header() {



  return (
    <header>
      <div className="line_header"></div>
      <img className='baner_header' src={MainBaner} alt="" />
    </header>
  )
}
