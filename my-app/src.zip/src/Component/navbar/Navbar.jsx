import React from 'react'
import './../navbar/navbar.css'
import Logo from './../../img_home/Group.png'
import Search from './../../img_home/Vector.png'
import Bin from './../../img_home/Group 1.png'
import Logoout from './../../img_home/Logout.png'
import { Link } from 'react-router-dom'


export default function Navbar() {
  return (
    <nav className='nav'>
      <div className="nav_container">
        <div className="logo_nav">
          <img src={Logo} alt="" />
        </div>
        <div className="list_nav_block">
        <ul className='list_nav'>
          <div className="link_hover">
          <Link className='first_child' to={'/'}>Home</Link>
<div className="link_line"></div>
          </div>
          
          <Link className='nav_list_li' to={'/about'}>Shop</Link>
          <li className='nav_list_li'>Plant Care</li>
          <li className='nav_list_li'>Blogs</li>
        </ul>
        </div>
       
        <div className="icon_search_nav">
          <img src={Search} alt="" />
        </div>
        <div className="icon_bin_nav">
          <Link to={"/shop_cart"}>
          <img src={Bin} alt="" />
          </Link>
        </div>
        <button className='login_nav'>
          <img className='icon_login' src={Logoout} alt="" />
        <span>Login</span>
        </button>
      </div>
    </nav>
  )
}
