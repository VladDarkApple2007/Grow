import React from 'react'
import './../footer/footer.css'

export default function Footer() {
  return (
    <div className='Footer'> Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta id nemo excepturi nisi, aspernatur eius ex voluptates doloremque? Placeat, cumque ipsum alias officiis culpa soluta eligendi incidunt asperiores aliquid harum!</div>
  )
}
