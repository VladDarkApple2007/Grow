import React, { useState } from 'react'
import './../BuutonNext/buuton_next.css'
import VectorRight from './../../img_home/Arrow - Right 2.png'


const NumberNext = [1, 2, 3, 4]

export default function BuutonNext() {

   const [nextButton, setNextButton] = useState([]);


  return (
    <div className="buuton_next">
  {NumberNext.map((number, id) => {
   return (
      <button key={id}
      onClick={() => setNextButton(id)}
      className={nextButton == id ? 'active_next_block' : 'number_next_block'}
      >
         
         <span>
         {number}
         </span>
      </button>
   )
  })}
  <button className='icon_next'><img src={VectorRight} alt="" /></button>
    </div>
  )
}
