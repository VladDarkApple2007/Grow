import Header from '../../Component/header/Header'
import CategoryHome from '../../Component/CategoryHome/CategoryHome'
import ProductHome from '../../Component/ProductHome/ProductHome'
import './../Home/home.css'
// import one from './../../img_home/image 2.png'
import SortHome from '../../Component/SortHome/SortHome'
import FilterBlock from '../../Component/FilterBlock/FilterBlock'
import SaleHome from './../../img_home/Super Sale Banner.png'
import BuutonNext from '../../Component/BuutonNext/BuutonNext'
import { useEffect, useState } from 'react'

// Super Sale Banner.png

export default function Home() {


  const [item, setItem] = useState([]);
  const [topCategory, SetTopCategory] = useState([]);

  // https://658abb30ba789a962237ac4e.mockapi.io/my-app

  useEffect (() => {
    fetch(`https://658abb30ba789a962237ac4e.mockapi.io/my-app?category=${topCategory}` )
    .then((res) =>{return res.json()})
    .then((arr) => {setItem(arr)} )
  }, [topCategory])

  console.log(item)

  return (
    <main>
      
    <Header/>
    <section className="section_home">
    <div className="home_container">
    

    <div className="home_container_filter">
      <FilterBlock />
      <div className="sale_home">
      <img  src={SaleHome} alt="" />
      </div>
    </div>
      <div className="home_container_product">
      <div className="home_category_sort">
      <CategoryHome value={topCategory} topCategory={(id) => SetTopCategory(id) } />
    <SortHome/>
      </div>
    
      <div className="product_home_flex">
      {item?.map((record, id )=> {
        return (
          <ProductHome key={record.id} name={record.name} price={record.price} img={record.img} lastprice={record.lastprice} /> 
        )

      })}
      </div>
      <div className="buuton_next_home">
        <BuutonNext/>
      </div>
      </div>
    
    
    
    </div>
    </section>
    </main>
    
      )
}


  



